const express = require("express");
const Movie = require('../model.js');
const router = express.Router();



router.post("/", async(req, res) =>{
    const movie = req.body;
    if(!movie.name  || !movie.date || !movie.genres){
        return res.status(400).json({ success: false, message: "Please provide all fields" });
    }

    const newMovie = new Movie(movie);

    try{
        await newMovie.save();
        res.status(201).json({ success: true, data: newMovie});
    }
    catch (error){
        console.error("Error in adding of movie: ", error.message);
        res.status(500).json({success: false, message: "Server Error"});
    }
})

// router.get("/", async(req, res) =>{
//     try {
//         const page = parseInt(req.query.page) || 1;
//         const startIndex = page * 6;
//         const endIndex = startIndex + 6;
//         var movies = await Movie.find();
//         movies = movies.slice(startIndex, endIndex)
//         res.status(200).json({ success: true, data: movies });
        
//     } catch (error) {
//         res.status(500).json({ message: error.message });
//     }
// })

router.get("/", async (req, res) => {
    try {
        // Ensure page is at least 1
        let page = parseInt(req.query.page) || 1;
        page = page < 1 ? 1 : page;

        const limit = 6;
        const startIndex = (page - 1) * limit;
        const endIndex = startIndex + limit;

        const movies = await Movie.find();
        const paginatedMovies = movies.slice(startIndex, endIndex);

        // if (paginatedMovies.length !== 0) {
        res.status(200).json({ success: true, data: paginatedMovies });
        // } else {
        //     res.status(404).json({ success: false, message: "No movies found" });
        // }
    } catch (error) {
        console.error("Error fetching movies:", error.message);
        res.status(500).json({ success: false, message: error.message });
    }
});


router.delete("/:id", async (req, res) => {
    const { id } = req.params;

    try {
        // Find the product by ID and delete it
        const deletedMovie = await Movie.findByIdAndDelete(id);

        // If no product is found, return a 404 error
        if (!deletedMovie) {
            return res.status(404).json({ success: false, message: "Movie not found" });
        }

        // Return a success message if the product was deleted
        res.status(200).json({ success: true, message: "Movie deleted successfully", data: deletedMovie });
    } catch (error) {
        console.error("Error in delete product: ", error.message);
        res.status(500).json({ success: false, message: "Server Error" });
    }
});

module.exports = router;