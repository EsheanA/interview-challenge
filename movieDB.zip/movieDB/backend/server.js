const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const connectDB = require('./db.js'); // Replace import with require for db connection
const path = require('path');
const movieRoutes  = require("./routes/movieRoutes.js");
// Load environment variables from .env file
dotenv.config({ path: path.resolve(__dirname, '../.env') });

const app = express();

// Middleware to parse JSON data in the request body
app.use(cors());
app.use(express.json());

app.use("/api/movies", movieRoutes);

// Start the server and connect to the database
app.listen(5000, () => {
    connectDB();
    console.log("Server started on port 5000");
});

