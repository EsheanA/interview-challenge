const mongoose = require('mongoose'); 
const Schema = mongoose.Schema;
const movieSchema = new Schema({
    name:{
        type: String,
        required: true
    },
    date:{
        type: String,
        required: true
    },
    genres: {
        Horror: { type: Boolean, required: true },
        Action: { type: Boolean, required: true },
        Comedy: { type: Boolean, required: true },
        Romance: { type: Boolean, required: true }
    },
    rating:{
        type : Number,
        default: 0
    },
    watched:{
        type: Boolean,
        default: false
    }
    
},
{
    timestamps: true
})

const movieModel = mongoose.model('Movie', movieSchema);
module.exports = movieModel;