import './App.css';
import {useState, useEffect} from 'react';
import CreateMovie from './components/CreateMovie';
import Nav from './components/Nav';
import Home from './components/Home'
import {AppProvider} from './app-context/context.js';


import {Route, Switch} from 'react-router-dom';
function App() {
  const [movies, setMovies] = useState([]);
  return (
    <div className="App">
      <Nav />
      <AppProvider>
        <Switch>
            <Route path = '/' component = {Home} exact/>
            <Route path = '/Create' component = {CreateMovie}/>
        </Switch>
      </AppProvider>
    </div>
  );
}

export default App;
