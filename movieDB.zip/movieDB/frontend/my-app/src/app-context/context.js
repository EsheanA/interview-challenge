import React, { createContext, useState } from 'react';

export const AppContext = createContext();

export const AppProvider = ({ children }) => {
    const [movies, setMovies] = useState([]);
    const [page, setPage] = useState(1);
    return (
    <AppContext.Provider value={[ movies, setMovies, page, setPage]}>
        {children}
    </AppContext.Provider>
    );
};