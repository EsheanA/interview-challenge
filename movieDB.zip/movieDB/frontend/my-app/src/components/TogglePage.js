import {useState, useEffect, useContext} from 'react';
import { AppContext } from '../app-context/context.js';

function TogglePage(){
    const [movies, setMovies, page, setPage] = useContext(AppContext);
    return(
        <div className = "togglePage">
            <input type = "button" value = "<--" onClick = {()=>{if(page!= 1){setPage(page-1)}}}/>
            <input type = "button" value = "-->" onClick = {()=>{setPage(page+1)}}/>
        </div>
    )
}

export default TogglePage;