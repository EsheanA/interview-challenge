import {useState} from 'react';
import { AppContext } from '../app-context/context.js';
import {useContext} from 'react'
function CreateMovie(){
    const [movies, setMovies, page, setPage] = useContext(AppContext);
    const [name, setName] = useState("");
    const [date, setDate] = useState("");
    const [genres, setGenres] = useState({
        Horror: false,
        Action:false,
        Comedy: false,
        Romance: false
    });
    const toggleGenre = (event) => {
        const { name, checked } = event.target;
        setGenres((prevGenres) => ({
            ...prevGenres,
            [name]: checked  // Update the genre based on checkbox state
        }));
    };
    const createMovie = async(event)=>{
        event.preventDefault();
        const endpoint = `http://localhost:5000/api/movies?page=${page}`;
        const data = {
            "name": name,
            "date": date,
            "genres": genres
        }
        try{
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)

            });
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const responseData = await response.json();
            console.log('Response:', responseData);
        }catch(error){
            console.error('Error:', error);
        }
        setName("");
        setGenres(
            {
                Horror: false,
                Action:false,
                Comedy: false,
                Romance: false
            }
        )
        // fetch(endpoint)
        //     .then(response => response.json())
        //     .then(data => {
        //         setMovies(data.data)
        //     })
        //     .catch(error => {
        //         console.error('Error fetching data:', error);
        //     });
    }
    return(
        <form  className="form" onSubmit={createMovie}>
            <label htmlFor="MovieName">Movie Name: </label>
            <input type="text" className="MovieName" value={name} onChange={(event) => setName(event.target.value)} />

            <label htmlFor="ReleaseYear">Release year: </label>
            <input type="date" className="ReleaseYear" value={date} onChange={(event) => setDate(event.target.value)} />

            <fieldset>
                <legend>Choose your movies genres:</legend>
                
                <label>
                    <input
                        type="checkbox"
                        name="Horror"
                        checked={genres.Horror}
                        onChange={toggleGenre}
                    />
                    Horror
                </label>

                <label>
                    <input
                        type="checkbox"
                        name="Action"
                        checked={genres.Action}
                        onChange={toggleGenre}
                    />
                    Action
                </label>

                <label>
                    <input
                        type="checkbox"
                        name="Comedy"
                        checked={genres.Comedy}
                        onChange={toggleGenre}
                    />
                    Comedy
                </label>

                <label>
                    <input
                        type="checkbox"
                        name="Romance"
                        checked={genres.Romance}
                        onChange={toggleGenre}
                    />
                    Romance
                </label>
            </fieldset>
            <input type="submit" value="Submit" />
        </form>
    )
}

export default CreateMovie;