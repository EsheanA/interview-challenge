import {Link} from 'react-router-dom';

function Nav(){
    return(
        <nav className = "navi">
            <h1>Movie App</h1>
            <div>
                <Link to = "/">Home</Link>
                <Link to = "/Create">Create</Link>
            </div>
        </nav>
    )
}
export default Nav;