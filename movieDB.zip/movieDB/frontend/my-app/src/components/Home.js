import Movie from './Movie';
import {useState, useEffect, useContext} from 'react';
import { AppContext } from '../app-context/context.js';
import TogglePage from './TogglePage';

function Home(){
    const [movies, setMovies, page, setPage] = useContext(AppContext);

    const deleteMovie = async(id)=>{
        const endpoint = `http://localhost:5000/api/movies/${id}`;
        try{
            const response = await fetch(endpoint, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                },
                id: JSON.stringify(id)

            });
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const responseData = await response.json();
            console.log('Response:', responseData);
        }catch(error){
            console.error('Error:', error);
        }
        fetchData();
    }
    const movieList = movies.map(
        (movie)=>
        (
            <Movie
                id= {movie._id}
                key = {movie._id}
                name = {movie.name}
                date = {movie.date}
                genres = {movie.genres}
                rating = {movie.rating}
                watched = {movie.watched}
                deleteSelf = {deleteMovie}
            />
        )
    )
    var fetchData = async()=>{
        const endpoint = `http://localhost:5000/api/movies?page=${page}`;
        console.log("hi")
        try{
            const response = await fetch(endpoint);
            const data = await response.json();
            setMovies(data.data);
            console.log(data.data)
        }catch(error){
            console.error('Error fetching data:', error);
        }
    }

    useEffect(()=>{
        localStorage.setItem("page", JSON.stringify(page));
        fetchData();
    }, [page])
    useEffect(()=>{
        const page_data = localStorage.getItem("page");
        if(page_data){
            setPage(JSON.parse(page_data))
        }
        else{
            localStorage.setItem("page", JSON.stringify(page));
        }
            fetchData();
    }, [])

   
    return(
        <div className = "Home">
            {movieList}
            <TogglePage/>
        </div>
    )
}
export default Home;