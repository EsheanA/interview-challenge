function Movie(props){

    return(
        <div className = "Movie">
            <input type = "button" value = "delete" onClick = {()=>{props.deleteSelf(props.id)}}/>
            <h2>{props.name}</h2>
            <p>Release date: {props.date}</p>
            <p>Status: {props.watched ? "watched": "unwatched"} </p>
            <p>Genres:{" "}
            {Object.entries(props.genres)
                .filter(([genre, isIncluded]) => isIncluded) 
                .map(([genre]) => genre) 
                .join(", ")} 
            </p>
        </div>
    )
}
export default Movie;